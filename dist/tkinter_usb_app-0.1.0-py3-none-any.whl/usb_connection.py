import time
import serial
import configparser
import os
import queue
import threading
import serial.tools.list_ports


class USBConnection:
    def __init__(self, update_terminal_callback, dispatcher_callback):
        # Initialize USBConnection with callbacks and settings
        self.update_terminal = update_terminal_callback
        self.dispatcher_callback = dispatcher_callback
        self.connection = None
        self.is_connected = False
        self.connection_established = False
        self.data_queue = queue.Queue()
        self.esp_to_queue = None
        self.waiting_for_idle = False
        self.running = False
        self.receive_running = False
        # Load configuration from config.ini
        self.load_config()

    def load_config(self):
        # Define the path to the config file
        config_file = os.path.join(os.path.dirname(__file__), "config.ini")

        # Create a ConfigParser object
        config = configparser.ConfigParser()

        # Read the config file
        config.read(config_file)

        # Get the USB settings
        self.port = config.get("USB", "PORT")
        self.baudrate = config.getint("USB", "BAUDRATE")

    def is_com_port_available(self):
        # Check if the specified COM port is available
        available_ports = [p.device for p in serial.tools.list_ports.comports()]
        return self.port in available_ports

    def establish_connection(self):
        # Establish a connection to the specified COM port
        if not self.is_com_port_available():
            self.update_terminal(f"COM port {self.port} is not available.")
            return False

        try:
            self.connection = serial.Serial(self.port, self.baudrate, timeout=1)
            self.is_connected = True
            return True
        except serial.SerialException as e:
            self.is_connected = False
            self.update_terminal(f"Error establishing connection: {e}")
            return False

    def esp_restart(self):
        # Send a restart command (Ctrl+C) to the ESP device
        if self.is_connected:
            self.connection.write("STOP")

    def check_esp_idle_response(self):
        # Check if the ESP device is in idle state
        if self.is_connected:
            self.write_command("STOP")
            time.sleep(0.2)
            self.start_esp_to_queue()
            self.start_read_queue()

    def write_command(self, command):
        # Write a command to the ESP device
        if self.is_connected:
            try:
                self.connection.write((command + "\n").encode())
                self.update_terminal(f"To STM: {command}")
            except serial.SerialException as e:
                self.update_terminal(f"Error sending command: {e}")
        else:
            self.update_terminal("Not connected to any device.")

    ############# Consume queue
    def start_read_queue(self):
        # Start a background thread to read the data queue
        self.reading_thread = threading.Thread(target=self.read_queue_loop, daemon=True)
        self.running = True
        self.reading_thread.start()

    def read_queue_loop(self):
        # Loop to read messages from the data queue and dispatch them
        global STATUS
        buffer = ""
        while self.running:
            while not self.data_queue.empty():
                buffer += (
                    self.data_queue.get() + "\n"
                )  # Add newline to simulate complete lines
                lines = buffer.split("\n")
                buffer = lines.pop()  # Keep the last partial line in the buffer

                if lines:
                    self.dispatcher_callback("\n".join(lines))
            time.sleep(0.0001)

    def stop_read_queue(self):
        # Stop the read queue loop
        self.running = False

    def queue_is_empty(self):
        # Check if the data queue is empty
        return self.data_queue.empty()

    ################ ESP to queue
    def start_esp_to_queue(self):
        # Start the ESP to queue thread
        self.receive_running = True
        threading.Thread(target=self.esp_to_queue_loop, daemon=True).start()

    def esp_to_queue_loop(self):
        # Loop to read responses from the ESP device and put them in the data queue
        buffer = ""
        while self.receive_running:
            try:
                # Read available data from the serial port
                if self.connection.in_waiting > 0:
                    buffer += self.connection.read(self.connection.in_waiting).decode()
                    lines = buffer.split("\n")
                    buffer = lines.pop()  # Keep the last partial line in the buffer

                    for line in lines:
                        if line.strip():
                            self.data_queue.put(line.strip())
            except Exception as e:
                print(f"Error in esp_to_queue: {e}")
                self.receive_running = False
                raise
